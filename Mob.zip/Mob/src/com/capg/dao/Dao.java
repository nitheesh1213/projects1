package com.capg.dao;

public interface Dao {

	void sortByName();
	void sortById();
	void sortByPrice();
	void delete(int k);

}
