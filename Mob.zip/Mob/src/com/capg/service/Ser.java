package com.capg.service;

public interface Ser {
	void sort();

	void del();
	

}
