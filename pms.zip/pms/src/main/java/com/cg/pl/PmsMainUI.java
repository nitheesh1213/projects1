package com.cg.pl;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.beans.Product;
import com.cg.service.IProductService;
import com.cg.service.ProductServiceImpl;

public class PmsMainUI {

	public static void main(String[] args) {
		System.out.println("Product Management System!!");
		System.out.println("1. Add a product");
		System.out.println("2. View All products");
		System.out.println("3. View Products by Type");

		IProductService service = new ProductServiceImpl();
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			System.out.println("Enter Product ID:");
			int id = sc.nextInt();
			System.out.println("Enter Poduct Name:");
			String name = sc.next();
			System.out.println("Enter Product Type");
			String type = sc.next();
			service.addProduct(id, name, type);
			break;
		case 2:
			List list = service.viewProducts();
			Iterator<Product> it = list.iterator();
			while (it.hasNext())
				System.out.println(it.next());
			break;
		case 3:
			String t = sc.next();
			List<Product> list2 = service.viewByType(t);
			Iterator<Product> it2 = list2.iterator();
			while (it2.hasNext())
				System.out.println(it2.next());
		default:

		}
	}

}
