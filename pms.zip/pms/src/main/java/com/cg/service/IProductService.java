package com.cg.service;

import java.util.List;

import com.cg.beans.Product;

public interface IProductService {
	public void addProduct(int id, String name, String type);

	public List<Product> viewProducts();
	
	public List<Product> viewByType(String type);
}
