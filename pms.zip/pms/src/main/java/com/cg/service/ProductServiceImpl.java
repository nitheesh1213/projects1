package com.cg.service;

import java.util.List;

import com.cg.beans.Product;
import com.cg.dao.IProductDAO;
import com.cg.dao.ProductDAOImpl;

public class ProductServiceImpl implements IProductService {
	IProductDAO dao = new ProductDAOImpl();
	
	public void addProduct(int id, String name, String type) {
		// TODO Auto-generated method stub
		Product product = new Product(id, name, type);
		dao.add(product);
	}

	public List<Product> viewProducts() {
		// TODO Auto-generated method stub
		return dao.get();
	}
	
	public List<Product> viewByType(String type){
		return dao.getByType(type);
	}

}
