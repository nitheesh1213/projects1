package com.cg.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.beans.Product;

public class ProductDAOImpl implements IProductDAO {
	private static Map<Integer, Product> map = new HashMap<Integer, Product>();
	static {
		map.put(11, new Product(4455, "Electronics", "Laptop"));
		map.put(22, new Product(4456, "Electronics", "Mobile"));
		map.put(33, new Product(4457, "Electronics", "Television"));
		map.put(44, new Product(4458, "Electronics", "Tablets"));
		map.put(55, new Product(4459, "Electronics", "Blutooth Speakers"));
		map.put(66, new Product(4452, "Books", "Java Book"));
		map.put(77, new Product(4453, "Fashion", "Jeans Tracks"));
		map.put(88, new Product(4454, "Jewellery", "bracellets"));
	}

	public void add(Product p) {
		map.put(11, p);
	}

	public List<Product> get() {

		Collection<Product> values = map.values();

		List<Product> list = new ArrayList();

		Iterator<Product> itr = values.iterator();
		while (itr.hasNext()) {
			list.add(itr.next());
		}

		return list;
	}

	public List<Product> getByType(String type) {
		Collection<Product> values = map.values();

		List<Product> list = new ArrayList<Product>();

		Iterator<Product> itr = values.iterator();
		while (itr.hasNext()) {
			list.add(itr.next());
		}

		List<Product> list2 = new ArrayList();
		Iterator<Product> itr2 = list.iterator();
		while (itr2.hasNext()) {
			if (itr2.next().getType().equalsIgnoreCase(type))
				list2.add(itr2.next());
		}
		
		return list2;

	}

}
