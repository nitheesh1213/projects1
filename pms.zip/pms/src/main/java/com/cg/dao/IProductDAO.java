package com.cg.dao;

import java.util.List;

import com.cg.beans.Product;

public interface IProductDAO {
	public void add(Product p);

	public List<Product> get();

	public List<Product> getByType(String type);
}
