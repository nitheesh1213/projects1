package com.capg.bank.dao;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.bank.bean.BankBean;

public class JUnitTesting {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {}
	BankDaoImpl dao=new BankDaoImpl();
 
	@Test
	public void getBalanceById(){
		BankBean bean=dao.getAccountBalence(12);
		//fail("Not yet implemented");
		//assertNotNull(bean);
		assertTrue(100==bean.getAmount());
	}

}