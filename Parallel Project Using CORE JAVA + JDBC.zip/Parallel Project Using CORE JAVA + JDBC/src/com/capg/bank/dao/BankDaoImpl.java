package com.capg.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capg.bank.bean.BankBean;

public class BankDaoImpl implements IBankDao {

	@Override
	public BankBean addAccount(BankBean bean) {
		Connection conn = DBConnect.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("insert into BankAccount values(acc_seq.nextval,?,?,?,?,?)");
			p.setString(1, bean.getCustomer_name());
			p.setString(2, bean.getContact_number());
			p.setDouble(3, bean.getAmount());
			p.setString(4, bean.getCity());
			p.setString(5, bean.getState());
			p.executeUpdate();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select acc_seq.currval from dual");
			if (rs.next())
				bean.setAccount_id(rs.getInt(1));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bean;
	}

	@Override
	public BankBean getAccountBalence(int account_id) {
		BankBean b = new BankBean();
		Connection conn = DBConnect.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankAccount where account_id=" + account_id);
			while (rs.next()) {
				b.setAccount_id(rs.getInt(1));
				b.setCustomer_name(rs.getString(2));
				b.setAmount(rs.getDouble(4));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}

	@Override
	public BankBean deposit(int account_id, double amount) {
		BankBean b = new BankBean();
		Connection conn = DBConnect.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankAccount where account_id=" + account_id);
			while (rs.next()) {
				b.setAccount_id(rs.getInt(1));
				b.setCustomer_name(rs.getString(2));
				b.setAmount(rs.getDouble(4) + amount);
			}
			PreparedStatement p = conn.prepareStatement(
					"update BankAccount set amount=" + b.getAmount() + " where account_id =" + account_id);
			p.executeUpdate();

			p = conn.prepareStatement("insert into Trans_info values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, account_id);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Deposited");
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}

	@Override
	public BankBean withdraw(int account_id, double amount) {
		BankBean b = new BankBean();
		Connection conn = DBConnect.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankAccount where account_id=" + account_id);
			while (rs.next()) {
				b.setAccount_id(rs.getInt(1));
				b.setCustomer_name(rs.getString(2));
				b.setAmount(rs.getDouble(4) - amount);
			}
			// System.out.println("new Bal "+b.getAmount());
			PreparedStatement p = conn.prepareStatement(
					"update BankAccount set amount=" + b.getAmount() + " where account_id =" + account_id);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, account_id);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "WithDraw");
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}

	@Override
	public BankBean fundTransfer(int account_id1, int account_id2, double amount) {
		BankBean b1 = new BankBean();
		Connection conn = DBConnect.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankAccount where account_id=" + account_id1);
			while (rs.next()) {
				b1.setAccount_id(rs.getInt(1));
				b1.setCustomer_name(rs.getString(2));
				b1.setAmount(rs.getDouble(4) - amount);
			}
			// System.out.println("new Bal "+b.getAmount());
			PreparedStatement p = conn.prepareStatement(
					"update BankAccount set amount=" + b1.getAmount() + " where account_id =" + account_id1);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, account_id1);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Fund Transfer To " + account_id2);
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BankBean b2 = new BankBean();

		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankAccount where account_id=" + account_id2);
			while (rs.next()) {
				b2.setAccount_id(rs.getInt(1));
				b2.setCustomer_name(rs.getString(2));
				b2.setAmount(rs.getDouble(4) + amount);
			}
			PreparedStatement p = conn.prepareStatement(
					"update BankAccount set amount=" + b2.getAmount() + " where account_id =" + account_id2);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, account_id2);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Fund Transfered From " + account_id1);
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b1;
	} 

	@Override
	public ArrayList printDetails(int account_id) {
		ArrayList<String> a = new ArrayList<String>();
		Connection conn = DBConnect.getConnection();
		String str = "";
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from Trans_info where account_id=" + account_id);
			while (rs.next()) {
				str = String.valueOf(rs.getInt(1))+"\t\t";
				str+=rs.getInt(2)+"\t\t";
				str+=rs.getDate(3)+"\t\t";
				str+=rs.getDouble(4)+"\t\t";
				str+=rs.getString(5);
				a.add(str);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;

	}

}
