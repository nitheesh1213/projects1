package com.capgemini.customerapp.exceptions;

public class LocaleException extends Exception{

	@Override
	public String toString() {
		
		return "Invalid Locality";
	}

	
}
