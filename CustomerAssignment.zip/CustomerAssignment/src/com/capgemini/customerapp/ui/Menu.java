package com.capgemini.customerapp.ui;

public enum Menu {
  ADD, VIEWALL, VIEWBYNAME, REMOVE, EDIT, VIEWBYID, EXIT
}
