package com.cg.dao;
import java.util.Map;

import com.cg.bean.*;
import com.cg.exception.InsuffecientFundException;
public interface AccountDAO {
	
	public void addAccount(Account ob);
	public boolean updateAccount(Account ob);
	public Account findAccount(int accno);
	public Map<Integer,Account> getAllAccounts();
    public double TransferMoney(Account from, Account to,double amount) throws InsuffecientFundException; 
    public void addprint(int accno,String report);
	public void getstatement(int id);
}
