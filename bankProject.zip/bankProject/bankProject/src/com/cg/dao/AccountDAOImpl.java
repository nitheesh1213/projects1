package com.cg.dao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.cg.bean.Account;
import com.cg.exception.InsuffecientFundException;

public class AccountDAOImpl implements AccountDAO {
    String ps;
    boolean b;
	static Map<Integer,Account> accmap = new HashMap<Integer,Account>();
	static Map<Integer,String> prt=new HashMap<Integer,String>();
	
	@Override
	public void addAccount(Account ob) {
		accmap.put(ob.getAid(), ob);
	}

	@Override
	public boolean updateAccount(Account ob) {
		// TODO Auto-generated method stub
        int accno=ob.getAid();
        accmap.put(accno, ob);
		return true;
	}
	@Override
	public Account findAccount(int accno) {
		// TODO Auto-generated method stub
		
		Account ob= accmap.get(accno);
		return ob;
	}

	@Override
	public Map<Integer, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return accmap;
	}

	@Override
	public double TransferMoney(Account from, Account to, double amount) throws InsuffecientFundException {
		// TODO Auto-generated method stub
		double new_balance=from.getBalance()-amount;
		double new_balance1=to.getBalance()+amount;
		String report=Double.toString(amount)+" Transferred to Account No : "+Integer.toString(to.getAid());
		addprint(from.getAid(), report);
		if(new_balance<1000.0 && amount>0)
		{
			new_balance=from.getBalance();
			new_balance1=to.getBalance();
			throw new InsuffecientFundException("Insufficient fund. Can not be transfered and Minimum balance of 1000 Should be Maintained",amount);
		}
		from.setBalance(new_balance);
		to.setBalance(new_balance1);
		AccountDAOImpl dao = new AccountDAOImpl();
		dao.updateAccount(from);
		dao.updateAccount(to);
		return new_balance;
	}
	 public void addprint(int accno,String report) {
		 Set<Integer> keys = prt.keySet();
		 for(Integer key: keys) {
			 if(accno == key){
				 b=true;
				 String s = prt.get(accno);
				 prt.put(accno, s+"\n"+report);
				 break;
			 }
		 }
		 if(!b)
			prt.put(accno, report);
	 }

	@Override
	public void getstatement(int id) {
		// TODO Auto-generated method stub
		System.out.println(prt.get(id));
	}
}
