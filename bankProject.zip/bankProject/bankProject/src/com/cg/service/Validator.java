package com.cg.service;

public interface Validator {
	//...............................regular expression for validating account number
String aidpattern="[1-9][0-9][0-9]";
//...............................regular expression for validating mobile number

String mobilepattern="[6-9]{1}[0-9]{9}";
//...............................regular expression for validating name of account user

String namepattern ="[A-Z][a-z]*+[']*[ ]*+[a-z]*+[ ]*+[a-zA-Z]*";
//...............................regular expression for validating balance

String balancepattern="[1-9][0-9][0-9][0-9][0-9]*+[.]*+[0-9]*";

public static boolean validatedata(String data, String pattern)
{
	return data.matches(pattern);
}
	
	
}
