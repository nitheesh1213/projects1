package com.cg.pl;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import com.cg.bean.*;
import com.cg.exception.InsuffecientFundException;
import com.cg.service.*;
public class MyWallet {
	public static void main(String args[]) throws IOException
	{
		  int id=0;
		  Long mb =0L;
		  int mb1=0;
		  String ah="";
		  double bal =0.0;
		  AccountService service = new AccountService();
		  AccountService service1 = new AccountService();
		  BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		  String choice="";
		while(true)
		{
		System.out.println("Menu\n-----------\n1 Create New Account\n2 Print All Accounts\n3 Witdraw Money\n4 Deposit Money\n5 Transfer Money\n6.Transaction Details\n7.Exit\nEnter your choice");
		choice=br.readLine();
		switch(choice)
		{
		case "1":
				  //Accepting and validating input for account number.......
				  System.out.println("Enter Account Number in Three Digits : ");
				  while(true)
				  {
					  String s_id=br.readLine();
					  boolean ch1=Validator.validatedata(s_id, Validator.aidpattern);
					  if(ch1==true)
					  {
						  try {
							  id=Integer.parseInt(s_id);
							  break;
						  }
						  catch(NumberFormatException e)
					  
					  {
						 System.out.println("Account Number must be numeric... Please,Re-enter"); 
					  }
				  }
					  else
					  {
						  System.out.println("Re Enter Account Number in 3 digits");
					  }
				  
				  }//end of while
				  //Accepting and validating input for mobile number
				  System.out.println("Enter mobile number");
				  while(true)
				  {
					  String s_mb=br.readLine();
					  boolean ch1=Validator.validatedata(s_mb, Validator.mobilepattern);
						  try {
							  Long.parseLong(s_mb);
						  }
						  catch(NumberFormatException e)
					  {
						 System.out.println("Mobile Number must be numeric. Re Enter"); 
					  }
					  if(ch1==false)
					  {
						  System.out.println("Re Enter Mobile Number in 10 digits");
					  }
					  if(ch1==true) {
						  mb=Long.parseLong(s_mb);
						  break;
					  }
				  
				  }//end of mobile validation
				  
				  //accepting and validating account holder
				  System.out.println("Enter Account holder With First letter as Capital : ");
				 while(true)
				  {
					  ah=br.readLine();
					  boolean ch1=Validator.validatedata(ah, Validator.namepattern);
					  if(ch1==false)
					  {
						  
						  System.out.println("Re Enter Name With First letter as Capital"); 
				       }
					  else
						  break;
				  }//end of mobile validation
				  // accepting and validating balance
				 System.out.println("Enter Balance");
				 while(true)
				  {
					 String s_bal=br.readLine();
					  boolean ch1=Validator.validatedata(s_bal, Validator.balancepattern);
						  try {
						    Double.parseDouble(s_bal);
						  }
						  catch(NumberFormatException e)
					  {
						 System.out.println("Balance must be numeric. Re Enter"); 
					  }
					  if(ch1==false)
					  {
						  System.out.println("Re Enter Balance");
					  }
					  if(ch1==true) {
						  bal= Double.parseDouble(s_bal);
						  break;
				  }
				  }
				  Account ob= new Account(id,mb,ah,bal);
			      service.addAccount(ob);
				  System.out.println("Account Created Successfully!");
				  break;
	    case "2"://print all accounts
	    	     
	    	     Map <Integer,Account> accmap=service.getAllAccounts();
	    	     Collection<Account> vc = accmap.values();
	    	     List<Account> acclist=new ArrayList<Account>(vc);
	    	     for(Account o : acclist)
	    	     {
	    	    	 service.printStatment(o);
	    	     }
			     break;
	    case "3":
	    	 
			  //--------------------- withdraw money
	    	 //---------------taking account number from which you want to deposit
			  System.out.println("Enter Account number to withdraw");
			  while(true)
			  {
				  String s_mb=br.readLine();
				  boolean ch1=Validator.validatedata(s_mb, Validator.aidpattern);
					  try {
						  Integer.parseInt(s_mb);
					  }
					  catch(NumberFormatException e)
				  
				  {
					 System.out.println("Account Number must be numeric. Re Enter"); 
				  }
					  if(ch1==true) {
						  mb1=Integer.parseInt(s_mb);
						 break;
					  }
				  else
				  {
					  System.out.println("Re Enter Account Number in 3 digits");
				  }
			  
			  }//end of while
			  //on basis of account number finding account
			  Account ob1=  service.findAccount(mb1);
			  System.out.println("=============================================");
			  System.out.println("Current Balance of Account is "+ob1.getBalance());
			  System.out.println("=============================================");
			  //Amount to be withdraw
			  System.out.println("Enter amount to withdraw");
			  while(true)
			  {
				  String s_bal1=br.readLine();
				  bal= Double.parseDouble(s_bal1);
				  if(bal>0)
				  {
						  break;
			  }
				  else
				  {
					  System.out.println("Invalid Amount...Please, Re Enter Amount");
				  }
			  
			  }
			  double b1= 0.0;
			try
			{
			 b1=service.withdraw(ob1, bal);
			System.out.println("After Withdraw Balance is "+b1);
			System.out.println("=============================================");
			System.out.println(" ");
			service.updateAccount(ob1);
			
			}
			catch(InsuffecientFundException e)
			{
				System.err.println(e.getMessage());
				System.err.println(e);
				
			}
		     break;
	    case "4":
	    	//Deposit
	    	//------------------------------account number to deposit
	    	System.out.println("Enter Account number to deposit");
			  while(true)
			  {
				  String s_mb1=br.readLine();
				  boolean ch1=Validator.validatedata(s_mb1, Validator.aidpattern);
				  if(ch1==true)
				  {
					  try {
						  mb1=Integer.parseInt(s_mb1);
						  break;
					  }
					  catch(NumberFormatException e)
				  
				  {
					 System.out.println("Account Number must be numeric. Re Enter"); 
				  }
			  }
				  else
				  {
					  System.out.println("Re Enter Account Number in 3 digits");
				  }
			  }
			  Account ob2=  service.findAccount(mb1);
			  System.out.println("=============================================");
			  System.out.println("Current Balance of Account is "+ob2.getBalance());
			  System.out.println("=============================================");
			  
			  //--------------------------------------------------------amount to be deposit
			  System.out.println("Enter amount to deposit");
			  
			  
			  while(true)
			  {
				  String s_bal2=br.readLine();
				  bal= Double.parseDouble(s_bal2);
				  if(bal>0)
				  {	  
						  break;	  
			  }
				  else
				  {
					  System.out.println("Invalid Amount.....Please, Re Enter Amount");
				  }
			  }
			  double b2= 0.0;
			try
			{
			 b2=service.Deposit(ob2, bal);
			System.out.println("After Deposit balance is "+b2);
			System.out.println("=============================================");
			System.out.println(" ");
			service.updateAccount(ob2);
			
			}
			catch(InsuffecientFundException e)
			{
				System.err.println(e.getMessage());		
			}
		     break;
	    
	    case "5":
	    	// transfer
	    	//------------------------------------------------account number of from account
	    	System.out.println("Enter Account number from which you want to withdraw");
	    	 while(true)
			  {
	    		 String s_mb3=br.readLine();
				  boolean ch1=Validator.validatedata(s_mb3, Validator.aidpattern);
				  if(ch1==true)
				  {
					  try {
						  mb1=Integer.parseInt(s_mb3);
						  break;
					  }
					  catch(NumberFormatException e)
				  
				  {
					 System.out.println("Account Number must be numeric. Re Enter"); 
				  }
			  }
				  else
				  {
					  System.out.println("Re Enter Account Number in 3 digits");
				  }
			  } 
	    	  Account ob3=  service.findAccount(mb1);
	    	  System.out.println("=============================================");
			  System.out.println("Current Balance of Account is "+ob3.getBalance());
			  System.out.println("=============================================");
	    	
			  //--------------------------------------------------account number of to account
			  System.out.println("Enter Account number to which you want to deposit");
			  while(true)
			  {
				  String s_mb4=br.readLine();
				  boolean ch1=Validator.validatedata(s_mb4, Validator.aidpattern);
				  if(ch1==true)
				  {
					  try {
						  mb1=Integer.parseInt(s_mb4);
						  break;
					  }
					  catch(NumberFormatException e)
				  
				  {
					 System.out.println("Account Number must be numeric. Re Enter"); 
				  }
			  }
				  else
				  {
					  System.out.println("Re Enter Account Number in 3 digits");
				  }
			  } 
			  Account ob4=  service1.findAccount(mb1);
			  System.out.println("=============================================");
			  System.out.println("Current Balance of Account is "+ob4.getBalance());
			  System.out.println("=============================================");
			  System.out.println("Enter amount to transfer ");
			  while(true)
			  {
				  String s_bal3=br.readLine();
				  bal= Double.parseDouble(s_bal3);
				  if(bal>0)
				  {
						  break;
			      }
				  else
				  {
					  System.out.println("Invalid Amount...Please, Re Enter Amount");
				  }
			  }
			  double b3= 0.0;
			  //...............................................Transferring amount.
			try
			{
			 b3=service.TransferMoney(ob3, ob4, bal);
			 
			System.out.println("After transfer new balance of First Account is  "+b3);
			System.out.println("=============================================");
			System.out.println(" ");
			service.updateAccount(ob3);
			service1.updateAccount(ob4);
			}
			catch(InsuffecientFundException e)
			{
				System.err.println(e.getMessage());
			}
		     break;
		case "6":
			// ...............taking account number to get transaction details
			    System.out.println("Enter Account Number to get Transaction Details : ");
			    while(true)
				  {
					  String acno=br.readLine();
					  boolean ch1=Validator.validatedata(acno, Validator.aidpattern);
					  if(ch1==true)
					  {
						  try {
							  id=Integer.parseInt(acno);
							  break;
						  }
						  catch(NumberFormatException e)
					  
					  {
						 System.out.println("Account Number must be numeric... Please,Re-enter"); 
					  }
				  }
					  else
					  {
						  System.out.println("Re Enter Account Number in 3 digits");
					  }
				  }
			    service.getstatement(id);
			      break;
		case "7":
			//....................................................exiting from switch case
		     System.out.println("Exit!!");
		     System.exit(0);
		     break;
	    default:
	    	    System.out.println("Invalid choice");	
		}	
		}		
	}
}